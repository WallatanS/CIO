#include<iostream>
#include<conio.h>
/*Vitor Carmona Locatelli Silva, 2019178440371*/
using namespace std;

int main(void)
{
    float a[10][10], b[10], x[10], y[10];
    int n = 0, m = 0, i = 0, j = 0;
    cout << "Informe o Tamanho da Matriz Quadrada (MAX.:10): ";
    cin >> n;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            cout << "Informe o Valor de: A(" << i << "," << j << ") = ";
            cin >> a[i][j];
        }
    }
    cout << "\nInforme os Valores dentro do Vetor\n";
    for (i = 0; i < n; i++)
    {
        cout << "Informe o Valor de: B(" << i << "," << j << ") = ";
        cin >> b[i];
    }
    cout << "\nInforme os Valores Iniciais de X\n";
    for (i = 0; i < n; i++)
    {
        cout << "Informe o Valor: X(" << i<<") =";
        cin >> x[i];
    }
    cout << "\nInforme o Numero de Iteracoes: ";
    cin >> m;
    while (m > 0)
    {
        for (i = 0; i < n; i++)
        {
            y[i] = (b[i] / a[i][i]);
            for (j = 0; j < n; j++)
            {
                if (j == i)
                    continue;
                y[i] = y[i] - ((a[i][j] / a[i][i]) * x[j]);
                x[i] = y[i];
            }
            printf("X%d = %.6f    ", i + 1, y[i]);
        }
        cout << "\n";
        m--;
    }
    return 0;
}
