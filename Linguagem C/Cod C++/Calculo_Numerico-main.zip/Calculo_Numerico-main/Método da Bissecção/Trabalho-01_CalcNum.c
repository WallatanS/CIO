#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>

/*CALCULO NUMERICO

		Determine a resistencia apropriada para dissipar energia a uma taxa especefica, com valores conhecidos para L e C. Para esse problema, suponha que a carga deve ser dissipada a um porcento do seu valor original(q/qo = 0,01) em t=0,05s, com L=5H e C=10^-4F. Use o metodo da Bisseccao. O método de Newton-Raphson pode ser incovenienteem virtude do cálculo da derivada.
								Vitor Carmona Locatelli Silva, 2019178440371;
								Wallatan França P Souza, 2019178440290.
	Por Bisseccao*/

int main(void){
	float Xi = 0 , Xr = 0 , Xu = 0 , AuxF , Fxi , Fxr , Erro = 1 , auxErro = 0 , Tol; /*Xi(Aprox. Inferior), Xu(Aprox. Superiror), Xr(Valor Estimado da Raiz), Erro(Erro Relativo Aproximado), Tol(Precisao dos Resultados)*/
	int cont = 0;
	printf("\t\t------Calculo Numerico------\n\n");
	printf("Informe o Valor de Aprox. Inferior: ");
	scanf("%f", &Xi);
	printf("Informe o Valor de Aprox. Superior: ");
	scanf("%f", &Xu);
	printf("Informe a Precisao Desejada(Ex.: 0.001): ");
	scanf("%f", &Tol);
	system("cls");

		while(fabs(Erro) > Tol){

			Xr = (Xi + Xu) / 2;

			Fxi = ((exp(-0.005 * Xi)) * (cos(sqrt(2000- 0.01 * Xi * Xi)*0.05))) - 0.01;
			Fxr = ((exp(-0.005 * Xr)) * (cos(sqrt(2000- 0.01 * Xr * Xr)*0.05))) - 0.01;

			AuxF = Fxi * Fxr;
			Erro = ((Xr - auxErro) / Xr) * 100;

			printf(" %d ITERACAO: ", cont + 1);
			printf(" \n \t    | Valor Estimado da Raiz %f", Xr); // Possiveis Raizes da Funcao
			printf("  -||-||-||-  Erro Relativo Aproximado: %f |", fabs(Erro));
			printf(" \n");

			auxErro = Xr;

			if(AuxF<0)
			{
				Xu=Xr;
			}
			else
			{
				Xi=Xr;
			}
		cont++;
	}
}
