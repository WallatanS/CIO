/*Vitor Carmona Locatelli Silva, 2019178440371
Wallatan França P Souza
*/
#include<iostream>
#include<cmath>
#include<iomanip>

using namespace std;

double f(double x);
double df(double x);

int main()
{
  double x = 0 , x1 , e , fx , dfx;

  cout.precision(6); // Define a quantidade de casas decimais pra 6
  cout.setf(ios::fixed); // Força a apresentação das 6 casas decimais mesmo quando não é necessário

  cout << "Informe o Valor de Aprox. Inicial:\n";
  cin >> x1;
  cout << "Informe a Tolerancia:\n";
  cin >> e;

  fx = f(x); // fx recebe o resultado da função f(x)
  dfx = df(x); // dfx recebe a derivada de fx, resultado da função df(x)

  cout << "--------||--------||--------||--------||--------||--------||--------||--------||--------||--------||--------||--------" << endl;
  do
  {
    x = x1;                                                                                                                              //  x recebe o ultimo valor calculado de x1
    fx = f(x);
    dfx = df(x);
    x1 = x - (fx / dfx);                                                                                                                 //  o método de Newton-Raphson em si
    cout << "X[i] --> " <<  x << "  ------  " << "X[i+1] --> " <<  x1 << "  ------  " << "|X[i+1] - X[i]| --> " <<  abs(x1-x) << endl;
  }while (fabs(x1 - x) >= e);                                                                                                            // o loop continua até o erro atingir a tolerancia informada
  cout << "--------||--------||--------||--------||--------||--------||--------||--------||--------||--------||--------||--------" << endl;

  cout << "Valor da Raiz : " << x1 << endl; // apresenta o valor refinado da raiz

  return 0;
}

double f(double x)
{
  return (((exp(-0.005 * x)) * (cos(sqrt(2000 - 0.01 * x * x) * 0.05))) - 0.01);                                                         //  retorna f(x), mesma equação usada no método da bissecção
}

double df(double x)
{
  float h = 0.000000001;
  return ((f(x + h) - f(x)) / h);                                                                                                        //  retorna a derivada de f(x)
}
