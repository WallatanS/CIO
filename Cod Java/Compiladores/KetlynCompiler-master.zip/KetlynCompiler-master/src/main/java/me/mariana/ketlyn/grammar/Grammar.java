package me.mariana.ketlyn.grammar;

public interface Grammar {
    String getName();
    int getIndex();
}
