package me.mariana.ketlyn.analyzers.semantic;

public class SemanticException extends RuntimeException {
    public SemanticException(String message) { super(message);}
}
