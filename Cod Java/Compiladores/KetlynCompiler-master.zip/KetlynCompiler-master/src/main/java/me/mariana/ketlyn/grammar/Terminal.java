package me.mariana.ketlyn.grammar;

import me.mariana.ketlyn.grammar.Grammar;

public interface Terminal extends Grammar {

}
