package me.Wallatan.Compiler.grammar;

public interface Terminal extends Grammar {

}
