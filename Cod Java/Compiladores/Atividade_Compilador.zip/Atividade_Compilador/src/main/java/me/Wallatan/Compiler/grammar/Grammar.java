package me.Wallatan.Compiler.grammar;

public interface Grammar {
    String getName();
    int getIndex();
}
