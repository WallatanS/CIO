package me.Wallatan.Compiler.analyzers;

import me.Wallatan.Compiler.grammar.Terminal;

public record TokenMetadata(
        Terminal token,
        String lexeme,
        int line,
        int column
) {
}
