package me.Wallatan.Compiler.analyzers.semantic;

public class SemanticException extends RuntimeException {
    public SemanticException(String message) { super(message);}
}
