package me.Wallatan.Compiler.analyzers.syntactic;

public class SyntacticException extends RuntimeException {
    public SyntacticException(String message) {
        super(message);
    }
}
