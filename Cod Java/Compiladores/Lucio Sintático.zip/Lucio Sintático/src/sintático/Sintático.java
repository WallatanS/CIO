

/**
 * @author Lucio Lisboa
 */

public class Sintático {
    
    public static void main(String[] args) {
        condicoes.inicio();
    }
}
